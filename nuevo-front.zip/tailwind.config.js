tailwind.config = {
    theme: {
      extend: {
        colors: {
          green: 'rgb(62, 177, 110)',
          lightGreen: 'rgb(216, 240, 226)',
          grayBg: 'rgb(153, 153, 153)',
          black: 'rgb(48, 48, 48)',
          lightGrayBg: 'rgb(244, 245, 246)',
          linesColor: 'rgb(230, 230, 230)'
        }
      }
    }
  }