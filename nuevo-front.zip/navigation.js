function createNavigation(){

    // Elementos para mostrar/ocultar
    const welcomeMessage = $('#welcome-message');
    const presentationsTable = $('#presentations-table-container');
    const usersTable = $('#users-table-container');
    
    
    
    // Elementos de navegación del panel
    const inicioNavItem = $('#inicio'); // Boton Inicio
    const listaNavItem = $('#lista'); // Botón Lista (en Presentaciones)
    const usuariosNavItem = $('#usuarios'); // Botón Usuarios
    
    
}
