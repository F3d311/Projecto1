// Datos de ejemplo 
const getUsers = async() => {
    return await fetch('./users.json')
        .then(response => response.json())
        .then(data => data)
}

let selectedUsersRowsCount = 0;
let selectedUsersRowsArray = []

async function createUsersTable(){
    // Creación DataTable
    const table = $('#users-table').DataTable({
        "columnDefs": [
            {
                "targets": [0, 2, 3, 4, 5], // Columnas no ordenables
                "orderable": false
            },
            {
                "targets": [-1], // Última columna
                "width": "200px" 
            },
            {
                "targets": [0], 
                "width": "20px" 
            },
            {
                "targets": [1], 
                "className": "text-right",
            },
            {
                "targets": [2], 
                "width": "10px",
            },
            {
                "targets": [3], // Columna nombre
                "className": "text-table-gray", // Color gris
                "width": "100px"
            },
        ],
        "order": [[1, "asc"]], // Columna id
        // Texto opciones de la tabla
        "language": {
            "lengthMenu": "_MENU_ Usuarios",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ Usuarios",
            "infoEmpty": "Mostrando 0 a 0 de 0 Usuarios",
            "emptyTable": "No se encontraron usuarios disponibles",
            "infoFiltered": "(Filtrados de un total de _MAX_ usuarios)",
            "zeroRecords": "No se encontraron usuarios con ese nombre",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        }, 
        "initComplete": function() {
            // Cursor pointer al dropdown de cantidad de registros para mostrar
            const lengthMenuDropdown = $(this).closest('.dataTables_wrapper').find('.dataTables_length select');
            lengthMenuDropdown.addClass('cursor-pointer');
        }
    });

    const users = await getUsers()

    // Agregar filas de datos a la tabla
    users.forEach(function(item) {
        const row = table.row.add([
            // Botón seleccionar
            `<div class="flex gap-2 items-center">
                <button class="select-button w-5 h-5 border-2 border-linesColor rounded-md hover:border-green">
                    <span class="select-button-content rounded-md">
                        <img src="assets/imgs/tick.png" alt="">
                    </span>
                </button>
            </div>`,
            item.id,
            `<div class="flex items-center justify-between">
                <button class="search-button w-6 h-6 border-2 border-grayBg bg-black rounded-md hover:bg-green">
                    <span class="search-button-content rounded-md">
                        <img 
                            src="assets/imgs/userInfo.png"
                            alt="">
                    </span>
                </button>
            </div>`,
            item.email,
            item.nombreApellido,
`            <div class="flex gap-2 items-center">
                <a href="/users/${item.id}/modify/" class="row-action-button w-7 h-7">
                    <img 
                        class="w-7 bg-green rounded-md border-2 border-grayBg hover:bg-black" 
                        src="assets/imgs/8 contacto hover.png"
                    />
                </a> 
                <a href="/users/${item.id}/delete/" data-toggle="confirmation" class="row-action-button w-7 h-7">
                    <img 
                        class="w-7 bg-green rounded-md border-2 border-grayBg hover:bg-black" 
                        src="assets/imgs/10 eliminar hover.png"
                    />
                </a>
            </div>`
        ]).draw().node();
        
        // Agregar el atributo pr-id a la fila
        $(row).attr('user_id', item.id);

    });

    // Hover sobre las row texto negro
    $('#users-table tbody').on('mouseenter', 'tr', function() {
        const row = $(this);
        row.find('td').addClass('!text-black');
        row.find('td:first-child button.select-button').addClass('border-black');
    });
    $('#users-table tbody').on('mouseleave', 'tr', function() {
        const row = $(this);
        row.find('td').removeClass('!text-black');
        row.find('td:first-child button.select-button').removeClass('border-black');
    });


    // mostrar u ocultar el mensaje de selección y actualizar el conteo
    function updateSelectedUsersMessage() {
        const selectedUsersMessage = $('#selectedUsersMessage');
        if (selectedUsersRowsCount > 0) {
            selectedUsersMessage.removeClass('hidden');
            $('#selectedUsersCount').text(selectedUsersRowsCount);
            $('#selectedCount').text(selectedUsersRowsCount);
            if (selectedUsersRowsCount === 1) {
                selectedUsersMessage.find('p').text(selectedUsersRowsCount + ' Seleccionado');
            } else {
                selectedUsersMessage.find('p').text(selectedUsersRowsCount + ' Seleccionados');
            }
        } else {
            selectedUsersMessage.addClass('hidden');
        }
    }

    // Deseleccionar todas las filas
    function deselectAllUsersRows() {
        const rows = $('#users-table tbody tr');
        rows.removeClass('selected-row');
        selectedUsersRowsCount = 0;
        selectedUsersRowsArray = []
        $('#selectAllUsersButton').removeClass('show-select-button-content');
        updateSelectedUsersMessage();
    }

    // Botón X para deseleccionar todo
    $('#deselectAllUsersButton').on('click', function () {
        deselectAllUsersRows();
    });

    // Botón seleccionar todas las filas
    $('#selectAllUsersButton').on('click', function () {
        // Seleccionar todas las filas
        const rows = $('#users-table tbody tr');

        if($(this).hasClass('show-select-button-content')){ // Si el botón seleccionar todos ya fue clickeado
            // Eliminar todas las selecciones de esa página
            deselectAllUsersRows()
            updateSelectedUsersMessage();

        }else {
            $(this).toggleClass('show-select-button-content');
            const selectedUsersRows = rows.filter(':not(.selected-row)'); // Filtrar filas no seleccionadas
            selectedUsersRows.each(function () {
                const userId = $(this).attr('user_id');
                selectedUsersRowsArray.push(userId)
            });
            selectedUsersRows.toggleClass('selected-row'); // Seleccionar filas filtradas
            selectedUsersRowsCount += selectedUsersRows.length;
            updateSelectedUsersMessage();

        }
    });

    // Seleccionar fila button
    $('#users-table tbody').on('click', 'button.select-button', function() {
        const row = $(this).closest('tr');
        row.toggleClass('selected-row');
        if(row.hasClass('selected-row')){
            selectedUsersRowsCount += 1
            selectedUsersRowsArray.push(row[0].attributes['user_id'].value)
        }else{
            selectedUsersRowsCount -= 1
            selectedUsersRowsArray = selectedUsersRowsArray.filter(row_id => row_id !== row[0].attributes['user_id'].value)
        }
        updateSelectedUsersMessage();
    });

    //Deseleccionar boton Seleccionar Todos si cambia de página
    $('#users-table').on( 'page.dt', function () {
        deselectAllUsersRows()
    } );

    const searchInput = $('#users-table_filter input');

    // Agrega una clase CSS cuando el input tenga contenido
    searchInput.on('input', function () {
        if (this.value.trim() !== '') {
            $(this).addClass('!bg-none');
        } else {
            $(this).removeClass('!bg-none');
        }
    });
}


